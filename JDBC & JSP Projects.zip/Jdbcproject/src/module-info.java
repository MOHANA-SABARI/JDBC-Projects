/**
 * 
 */
/**
 * 
 */
module Jdbcproject {
	requires java.sql;
}